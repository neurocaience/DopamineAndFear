#!/bin/bash

# The Python script and arguments used to generate this file:
#
# python run_job.py --root /tigress/lxcai/experiments/ --mouse_num m191 m216 m224 m247 m250 m251 --datadir /tigress/lxcai/EXTgcamp/fe/data/CNN_context1_sorted/ --pretrained 1 --mIDs data/mIDs.csv --name EXTgc_20190705

#SBATCH --mail-user=lxcai@princeton.edu
#SBATCH --mail-type=end
#SBATCH --mem 150G
#SBATCH --nodes=1
#SBATCH --gres=gpu:tesla_p100:1
#SBATCH --ntasks-per-node=5
#SBATCH --output=/tigress/lxcai/experiments//augment-1_mouse_num-m216_lr-0.001_model-resnet18_pretrained-1/out.txt
#SBATCH --time=24:00:00

#Greg's Environment
#module load cudatoolkit/8.0 cudann/cuda-8.0/5.1
#module load anaconda3
#source activate fe
#cd /scratch/gpfs/gwg3/fe

#Lili's Environment
module load anaconda3/5.3.1
source activate ptorch
cd /tigress/lxcai/fe.git/trunk


python -O train.py --name=EXTgc_20190705 --mouse_num=m216 --batch_size=128 --n_epochs=200 --wall_time=24 --datadir=/tigress/lxcai/EXTgcamp/fe/data/CNN_context1_sorted/ --seed=0 --lr=0.001 --directory=/tigress/lxcai/experiments//augment-1_mouse_num-m216_lr-0.001_model-resnet18_pretrained-1 --augment=1 --model=resnet18 --mIDs=data/mIDs.csv --pretrained=1 