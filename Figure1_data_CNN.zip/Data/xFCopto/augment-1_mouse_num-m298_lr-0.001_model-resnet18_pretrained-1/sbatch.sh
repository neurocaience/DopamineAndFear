#!/bin/bash

# The Python script and arguments used to generate this file:
#
# python run_job.py --root /tigress/lxcai/experiments/xFCopto_cnn2 --mouse_num m1017 m1019 m1020 m1021 m1022 m1023 m1024 m1025 m1026 m1028 m0129 m1030 m1046 m1048 m1050 m1051 m1052 m277 m278 m280 m281 m285 m286 m287 m294 m296 m297 m298 m532 m537 m539 m541 m542 m546 m551 m552 m561 m562 m563 m564 m567 m568 m570 m575 m576 m577 m862 m863 m864 m865 m874 m875 m876 m882 m883 m884 m890 m891 m907 m975 m976 m978 --datadir /tigress/lxcai/FCopto/ --pretrained 1 --mIDs /tigress/lxcai/mIDs_FCopto_extra.csv --name FCopto_10042019

#SBATCH --mail-user=lxcai@princeton.edu
#SBATCH --mail-type=end
#SBATCH --mem 150G
#SBATCH --nodes=1
#SBATCH --gres=gpu:tesla_p100:1
#SBATCH --ntasks-per-node=5
#SBATCH --output=/tigress/lxcai/experiments/xFCopto_cnn2/augment-1_mouse_num-m298_lr-0.001_model-resnet18_pretrained-1/out.txt
#SBATCH --time=24:00:00

#Greg's Environment
#module load cudatoolkit/8.0 cudann/cuda-8.0/5.1
#module load anaconda3
#source activate fe
#cd /scratch/gpfs/gwg3/fe

#Lili's Environment
module load anaconda3/5.3.1
source activate ptorch
cd /tigress/lxcai/fe.git/trunk


python -O train.py --name=FCopto_10042019 --mouse_num=m298 --batch_size=128 --n_epochs=200 --wall_time=24 --datadir=/tigress/lxcai/FCopto/ --seed=0 --lr=0.001 --directory=/tigress/lxcai/experiments/xFCopto_cnn2/augment-1_mouse_num-m298_lr-0.001_model-resnet18_pretrained-1 --augment=1 --model=resnet18 --mIDs=/tigress/lxcai/mIDs_FCopto_extra.csv --pretrained=1 