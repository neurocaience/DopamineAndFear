#!/bin/bash

# The Python script and arguments used to generate this file:
#
# python run_job.py --root /tigress/lxcai/experiments/xFCgc --mouse_num 1103 1104 1106 4471 4472 4473 m084 m085 m145 m191 m205 m216 m217 m222 m224 m247 m249 m250 m251 m280 m281 m282 m283 m216 m224 m247 m250 m251 m739 m741 m747 m7136 m7137 m7138 m7168 m8203 m8205 --datadir /tigress/lxcai/FCgcamp/ --pretrained 1 --mIDs /tigress/lxcai/mIDs_FCgc_extra.csv --name EXTgc_09232019

#SBATCH --mail-user=lxcai@princeton.edu
#SBATCH --mail-type=end
#SBATCH --mem 150G
#SBATCH --nodes=1
#SBATCH --gres=gpu:tesla_p100:1
#SBATCH --ntasks-per-node=5
#SBATCH --output=/tigress/lxcai/experiments/xFCgc/augment-1_mouse_num-m281_lr-0.001_model-resnet18_pretrained-1/out.txt
#SBATCH --time=24:00:00

#Greg's Environment
#module load cudatoolkit/8.0 cudann/cuda-8.0/5.1
#module load anaconda3
#source activate fe
#cd /scratch/gpfs/gwg3/fe

#Lili's Environment
module load anaconda3/5.3.1
source activate ptorch
cd /tigress/lxcai/fe.git/trunk


python -O train.py --name=EXTgc_09232019 --mouse_num=m281 --batch_size=128 --n_epochs=200 --wall_time=24 --datadir=/tigress/lxcai/FCgcamp/ --seed=0 --lr=0.001 --directory=/tigress/lxcai/experiments/xFCgc/augment-1_mouse_num-m281_lr-0.001_model-resnet18_pretrained-1 --augment=1 --model=resnet18 --mIDs=/tigress/lxcai/mIDs_FCgc_extra.csv --pretrained=1 